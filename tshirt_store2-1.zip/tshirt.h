#ifndef TSHIRT_H
#define TSHIRT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "readline.h"


#define ORG_NAME_LEN 50
#define SIZE_LEN 3

struct tshirt {
	char org_name[ORG_NAME_LEN+1];
	char size[SIZE_LEN+1];
	double price;
	int quantity;



	struct tshirt *next;
};

/////////////////////////
// function prototypes //
/////////////////////////

struct tshirt *add_to_inventory(struct tshirt *inventory);
void search_by_organization(struct tshirt *inventory);
void search_by_size(struct tshirt *inventory);
void print_inventory(struct tshirt *inventory);
void clear_inventory(struct tshirt *inventory);
int read_line(char str[], int n);
void help();

#endif

/*
Author:Geonhee Choi project10-> This program's read_line function read
 the student organization,size->and then, add node as inventory parameter as ordered linkedlist->  search tshirt by name of organization,size
and then print the organization's name,size,t-shirt price, quantity-> clear inventory (list)
This program distributed by makefile and header
file  readline.c work for readline function, readeline.h work to store function definition with library, tshirt_store2.c work for execution of mainfunction, tshirt.c work for execution of another functions without main funtion, thsirt.h work for struct and function definitions with libraries


*/
