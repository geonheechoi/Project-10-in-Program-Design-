#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "tshirt.h"
#include "readline.h"

//read all
int read_line(char str[], int n) {
	int ch, i=0;

	while (isspace(ch = getchar()))
		;
	str[i++] = ch;
	while ((ch = getchar()) != '\n') {
		if (i < n)
			str[i++] = ch;
	}
	str[i] = '\0';
	return i;
}

/*
Author:Geonhee Choi project10-> This program's read_line function read
 the student organization,size->and then, add node as inventory parameter as ordered linkedlist->  search tshirt by name of organization,size
and then print the organization's name,size,t-shirt price, quantity-> clear inventory (list)
This program distributed by makefile and header
file  readline.c work for readline function, readeline.h work to store function definition with library, tshirt_store2.c work for execution of mainfunction, tshirt.c work for execution of another functions without main funtion, thsirt.h work for struct and function definitions with libraries


*/
